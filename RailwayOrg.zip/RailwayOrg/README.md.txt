RAILWAY ORGANIZATION SYSTEM:

Client Side:

The functionalities include:

	-> Train ticket booking
	-> PNR enquiry
	-> Search trains
	-> Get train schedule
	-> Help page

Server Side:

The functionalities include:

	-> Updating the trains table
	-> Displaying available trains
	-> Cancelling tickets
	-> Passenger status

This project is made on version Python 3.7 and may not work well with the latest versions and hence bit modifications might be required in order to run the project

Password for accessing the client side privilege is
	Username: ASHISH
	Password: 0807

Password for accessing the server side privilege is
	Password: *****

Run the server project first and update the database and later run the client side to access the contents. 